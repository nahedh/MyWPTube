  <footer style="text-align:center; padding: 20px; background:#eee;">
    <p>&copy; <?php echo date('Y'); ?> ناهض الحربي - جميع الحقوق محفوظة</p>
  </footer>
  <?php wp_footer(); ?>
</body>
</html>